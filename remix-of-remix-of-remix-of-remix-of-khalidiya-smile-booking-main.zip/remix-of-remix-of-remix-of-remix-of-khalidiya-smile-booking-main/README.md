# Remix of Remix of Remix of Remix of Khalidiya Smile Booking

Build a premium, multi-page website for British Dental Clinic, an established dental clinic in Khalidiya, Abu Dhabi, open since the late 1970s. The current site is outdated; this is a full redesign. It must feel like a high-end private clinic or an editorial magazine, NOT a SaaS template or an AI-generated site.

BRAND COLOURS — USE ONLY THESE THREE, NOTHING ELSE
1. Deep Navy #00114A: primary colour for headings, text, dark sections, footer and buttons.
2. Crimson #B10000: accent only, used sparingly (under 5% of any screen) for small details such as the key CTA hover, thin rules, active nav underline and one highlight word per section.
3. White #FFFFFF: all backgrounds and text on dark sections.
Rules: no other hues. For soft greys, use Navy at 6–12% opacity on white. No gradients. No shadows heavier than a faint navy-tinted one. No purple, teal or blue-to-purple anything. Define these as CSS variables and use them everywhere.

TYPOGRAPHY (Google Fonts)
- Headings: "Cormorant Garamond", weights 500/600, large, with tight tracking and generous line height.
- Body, nav and buttons: "Jost", weights 300/400/500.
- Do NOT use Inter, Roboto, Arial or system fonts. Large type scale, small uppercase labels with wide letter-spacing for section eyebrows.

ANTI-"AI LOOK" RULES
- No emojis, no glassmorphism, no glowing blobs, no gradient text, no sparkle icons, no generic icon-in-circle feature grids.
- Do not make every section a centered row of three equal cards. Use asymmetric editorial layouts, offset images, large numerals, thin 1px hairline dividers and generous white space.
- Real, specific copy. Never use lorem ipsum or phrases like "unlock your smile" or "revolutionize".
- Photography: use image placeholders with clear labels (e.g. "Clinic reception photo", "Dr portrait") sized so real photos can drop in. Do not generate fake faces.
- Motion: subtle only, such as a gentle fade-up on scroll and slow image reveals. No bouncing or parallax gimmicks.

PAGES (React Router, shared header and footer)
1. Home: full-height hero with a headline like "Abu Dhabi's dentists since the 1970s", a short line about 40+ years of care, and two buttons: "Book on WhatsApp" (primary) and "View treatments". Then a heritage section (large "40+ years" numeral), a treatments overview, a team teaser, a smile-gallery teaser, a patient-reviews strip, and a visit/location block.
2. Our Dentists: team profiles with portrait placeholders, name, role and qualifications as editable placeholders.
3. Treatments: Cosmetic Dentistry and Smile Makeovers (veneers, whitening, gum contouring), General Dentistry (fillings, root canal, crowns), Children's Dentistry, Adult Braces and Orthodontics, Implants. Each has its own detail section with a short description and a "Ask about this on WhatsApp" link.
4. Smile Gallery: before/after slider component with placeholders and a note "Shown with patient consent".
5. Dental Concerns: an accordion FAQ (tooth pain, sensitivity, stained teeth, missing teeth, children's first visit).
6. Patient Info: opening hours (placeholder to confirm), insurance accepted (placeholder), first-visit guide, and an embedded Google Map for Khalidiya Park Tower, Mezzanine Floor, 416 Zayed The First St, Al Khalidiyah, Abu Dhabi.
7. Contact: phone +971 2 677 3308, address, WhatsApp and the appointment form.

WHATSAPP APPOINTMENT FLOW (core feature)
- WhatsApp number: 971503137733 (link format https://wa.me/971503137733).
- Sticky header CTA "Book on WhatsApp" on all pages.
- A floating WhatsApp button, bottom-right on mobile and desktop, styled in Navy with a white WhatsApp glyph (do NOT use WhatsApp green, to stay inside the 3-colour palette).
- Appointment form (name, phone, treatment dropdown, preferred day, preferred time slot, new or existing patient). On submit, build a prefilled message with encodeURIComponent and open https://wa.me/971503137733?text=... in a new tab. Example text: "Hello British Dental Clinic, I'd like to book an appointment. Name: X, Treatment: Y, Preferred day/time: Z." Include validation and a short success confirmation. No backend needed.

LAYOUT AND UX
- Mobile-first, fully responsive, fast, with lazy-loaded images. The header becomes a refined full-screen menu on mobile.
- Header: logo (placeholder component, I will upload the real logo), nav (Our Dentists, Treatments, Smile Gallery, Dental Concerns, Patient Info), WhatsApp CTA.
- Footer (Navy background): address, phone, hours, links, Facebook link (facebook.com/britishdentalclinic), and this exact legal text: "© 2026 British Dental Medical Clinic LLC, PO Box 4374, Abu Dhabi, UAE. MOH: MF193 / CN-1042961. MOHAP Advertisement License No: WI5O55HM-220226, valid until 18/02/2027."
- Accessible contrast and focus states, semantic HTML, alt text.

MEDICAL-ADVERTISING COMPLIANCE
- No superlatives like "best dentist", no guaranteed results, no unverified claims. Before/after images need a consent note.

SEO
- Unique title and meta description per page, Open Graph tags, Dentist/LocalBusiness JSON-LD with the address, phone and opening hours.

OPTIONAL (build after the above works): an English/Arabic toggle with full RTL support.

Build the Home page first, then the rest. Keep the code clean and componentised, with the colours and fonts in one design-token file.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/6bf66050-1001-48fa-851d-19277396b353).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
