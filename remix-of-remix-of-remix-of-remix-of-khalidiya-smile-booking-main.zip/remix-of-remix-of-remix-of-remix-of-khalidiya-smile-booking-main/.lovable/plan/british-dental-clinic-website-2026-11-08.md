# British Dental Clinic website

## User experience
- Replace the placeholder home page with a refined, editorial clinic website in the supplied navy, crimson, and white palette.
- Add Our Dentists, Treatments, Smile Gallery, Dental Concerns, Patient Info, and Contact pages with shared navigation and footer.
- Add responsive mobile navigation, WhatsApp booking links, a floating contact button, and a validated appointment form that opens a prefilled WhatsApp message.
- Mark unprovided portraits, team details, reviews, opening hours, and insurance information as placeholders; use no fabricated patient photography or claims.

## Technical details
- Use the existing TanStack Start file-based router and the current shadcn Button component; do not add React Router or a backend.
- Centralize the supplied brand tokens and typography in `src/styles.css`, and load the requested Google Fonts from the root head.
- Add route-specific titles, descriptions, Open Graph metadata, and Dentist structured data using only supplied clinic facts.
- Verify route matching, appointment form validation/message generation, responsive navigation, and preview/build diagnostics.