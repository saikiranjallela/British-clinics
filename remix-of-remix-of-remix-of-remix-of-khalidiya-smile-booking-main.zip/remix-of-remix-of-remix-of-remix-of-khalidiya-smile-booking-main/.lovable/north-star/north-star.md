<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

Patients get the dental care they need from the clinic.

## Metric

Patients who request an appointment each month
