import { QueryClient } from "@tanstack/react-query";
import { createRouter, rootRouteId } from "@tanstack/react-router";
import { describe, expect, it } from "vitest";

import { routeTree } from "@/routeTree.gen";
import { appointmentSchema, whatsappLink } from "@/lib/clinic-data";

// Match routes without running loaders or rendering: loaders may need a server or
// network the test run lacks, and jsdom never loads the stylesheets React waits on.
describe("App routing", () => {
  it("matches a page for / instead of falling back to not found", () => {
    const router = createRouter({ routeTree, context: { queryClient: new QueryClient() } });

    const matches = router.matchRoutes("/");

    expect(matches.at(-1)?.routeId).not.toBe(rootRouteId);
  });

  it.each([
    "/dentists",
    "/treatments",
    "/smile-gallery",
    "/dental-concerns",
    "/patient-info",
    "/contact",
  ])("matches the clinic page at %s", (path) => {
    const router = createRouter({ routeTree, context: { queryClient: new QueryClient() } });
    const matches = router.matchRoutes(path);
    expect(matches.at(-1)?.routeId).not.toBe(rootRouteId);
  });

  it("accepts a valid appointment request with the clinic's required details", () => {
    expect(appointmentSchema.safeParse({
      name: "Amina Patient",
      phone: "+971 50 123 4567",
      treatment: "General dentistry",
      day: "Tuesday",
      time: "Morning",
      patient: "New patient",
    }).success).toBe(true);
  });

  it("rejects invalid phone numbers and unlisted treatment values", () => {
    expect(appointmentSchema.safeParse({
      name: "Amina Patient",
      phone: "call me",
      treatment: "Unlisted service",
      day: "Tuesday",
      time: "Morning",
      patient: "New patient",
    }).success).toBe(false);
  });

  it("uses the clinic WhatsApp number and encodes appointment text", () => {
    expect(whatsappLink("Name: Amina & treatment: General dentistry")).toBe(
      "https://wa.me/971503137733?text=Name%3A%20Amina%20%26%20treatment%3A%20General%20dentistry",
    );
  });
});
