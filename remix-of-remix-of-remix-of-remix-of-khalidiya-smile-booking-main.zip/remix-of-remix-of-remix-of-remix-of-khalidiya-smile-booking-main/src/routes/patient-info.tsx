import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { PageIntro, SectionEyebrow } from "@/components/clinic-site";
import { clinic, clinicPageMeta } from "@/lib/clinic-data";
import entrancePhoto from "@/assets/clinic-entrance.png.asset.json";

export const Route = createFileRoute("/patient-info")({
  component: PatientInfoPage,
  head: () => clinicPageMeta("Patient Information | British Dental Clinic Abu Dhabi", "Plan a visit to British Dental Clinic in Khalidiya, Abu Dhabi. Opening hours and insurance information are awaiting confirmation.", "/patient-info"),
});

function PatientInfoPage() {
  return <>
    <PageIntro eyebrow="Patient information" title={<>A little more about your <em>visit.</em></>} copy="Find the clinic, prepare for a first appointment and check practical details before you come in." />
    <section className="content-section"><div className="content-section-inner info-grid">
      <div><SectionEyebrow>At a glance</SectionEyebrow><h2>Before you arrive</h2><p><strong>Opening hours:</strong> To be confirmed by the clinic.</p><p><strong>Insurance accepted:</strong> To be confirmed by the clinic.</p><p><strong>Address:</strong> {clinic.address}</p><Link className="text-link" to="/contact">Contact the clinic <ArrowRight /></Link></div>
      <div><SectionEyebrow>Your first visit</SectionEyebrow><h2>Getting started</h2><ol><li>Send an appointment enquiry or call the clinic.</li><li>Share your preferred day and time with the team.</li><li>Ask the clinic what information to bring for your visit.</li></ol><p>First-visit instructions are subject to confirmation by the clinic.</p></div>
    </div></section>
    <section className="content-section"><div className="content-section-inner"><SectionEyebrow>Find the clinic</SectionEyebrow><h2 className="section-title">Khalidiya Park <em>Tower.</em></h2><p className="section-copy">Mezzanine Floor, 416 Zayed The First St, Al Khalidiyah, Abu Dhabi.</p><img className="clinic-photo visit-photo" src={entrancePhoto.url} alt="British Dental Clinic entrance at Khalidiya Park Tower" loading="lazy" /><iframe className="map-frame" title="Map showing British Dental Clinic at Khalidiya Park Tower" loading="lazy" src="https://maps.google.com/maps?q=Khalidiya%20Park%20Tower%2C%20416%20Zayed%20The%20First%20St%2C%20Abu%20Dhabi&t=&z=15&ie=UTF8&iwloc=&output=embed" referrerPolicy="no-referrer-when-downgrade" /></div></section>
  </>;
}