import { createFileRoute } from "@tanstack/react-router";
import { PageIntro, SectionEyebrow } from "@/components/clinic-site";
import { clinicPageMeta } from "@/lib/clinic-data";
import receptionPhoto from "@/assets/clinic-reception.png.asset.json";
import treatmentRoomPhoto from "@/assets/clinic-treatment-room.png.asset.json";
import consultationAreaPhoto from "@/assets/clinic-consultation-area.png.asset.json";
import entrancePhoto from "@/assets/clinic-entrance.png.asset.json";

export const Route = createFileRoute("/dentists")({
  component: DentistsPage,
  head: () => clinicPageMeta("Our Dentists | British Dental Clinic Abu Dhabi", "Meet the dental team at British Dental Clinic in Khalidiya, Abu Dhabi. Staff profiles and qualifications are being confirmed.", "/dentists"),
});

function DentistsPage() {
  return <>
    <PageIntro eyebrow="Our dentists" title={<>People behind the <em>practice.</em></>} copy="Explore the real spaces at British Dental Clinic while the clinical team’s names and profiles are confirmed." />
    <section className="content-section"><div className="content-section-inner"><SectionEyebrow>Inside the clinic</SectionEyebrow><div className="clinic-photo-grid">
      <figure><img src={receptionPhoto.url} alt="Reception and waiting area at British Dental Clinic" loading="lazy" /><figcaption>Reception</figcaption></figure>
      <figure><img src={treatmentRoomPhoto.url} alt="Dental treatment room at British Dental Clinic" loading="lazy" /><figcaption>Treatment room</figcaption></figure>
      <figure><img src={consultationAreaPhoto.url} alt="Consultation and waiting area at British Dental Clinic" loading="lazy" /><figcaption>Consultation area</figcaption></figure>
      <figure><img src={entrancePhoto.url} alt="The British Dental Clinic entrance in Abu Dhabi" loading="lazy" /><figcaption>Clinic entrance</figcaption></figure>
    </div><p className="profile-note">Dentist names, roles and qualifications will be added once confirmed by the clinic.</p></div></section>
  </>;
}