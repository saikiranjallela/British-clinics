import { createFileRoute } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { AppointmentForm, PageIntro, SectionEyebrow } from "@/components/clinic-site";
import { clinic, clinicPageMeta, whatsappLink } from "@/lib/clinic-data";

export const Route = createFileRoute("/contact")({
  component: ContactPage,
  head: () => clinicPageMeta("Contact & Appointments | British Dental Clinic Abu Dhabi", "Contact British Dental Clinic in Khalidiya, Abu Dhabi by phone or WhatsApp, or send an appointment enquiry.", "/contact"),
});

function ContactPage() {
  return <>
    <PageIntro eyebrow="Contact" title={<>We’re here to <em>listen.</em></>} copy="For appointments and enquiries, speak with the clinic by phone or WhatsApp, or share your preferred details below." />
    <section className="content-section"><div className="content-section-inner contact-layout">
      <aside className="contact-details"><SectionEyebrow>Reach the clinic</SectionEyebrow><h2>Get in touch.</h2>
        <div className="contact-entry"><p className="eyebrow">Call</p><a href="tel:+97126773308">{clinic.phone}</a></div>
        <div className="contact-entry"><p className="eyebrow">WhatsApp</p><a href={whatsappLink()} target="_blank" rel="noreferrer">Start a conversation <ArrowUpRight /></a></div>
        <div className="contact-entry"><p className="eyebrow">Visit</p><p>{clinic.address}</p></div>
        <div className="contact-entry"><p className="eyebrow">Opening hours</p><p>To be confirmed by the clinic</p></div>
      </aside>
      <div className="contact-form-wrap"><SectionEyebrow>Appointment enquiry</SectionEyebrow><h2>Tell us what works for you.</h2><AppointmentForm /></div>
    </div></section>
    <section className="content-section contact-map-section"><div className="content-section-inner"><SectionEyebrow>Visit the clinic</SectionEyebrow><iframe className="map-frame" title="Map showing British Dental Clinic in Khalidiya, Abu Dhabi" loading="lazy" src="https://maps.google.com/maps?q=Khalidiya%20Park%20Tower%2C%20416%20Zayed%20The%20First%20St%2C%20Abu%20Dhabi&t=&z=15&ie=UTF8&iwloc=&output=embed" referrerPolicy="no-referrer-when-downgrade" /></div></section>
  </>;
}