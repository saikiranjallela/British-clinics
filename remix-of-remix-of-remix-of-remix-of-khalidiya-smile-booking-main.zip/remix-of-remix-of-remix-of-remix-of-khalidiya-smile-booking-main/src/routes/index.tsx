import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, ArrowUpRight } from "lucide-react";
import { SectionEyebrow } from "@/components/clinic-site";
import { clinic, clinicPageMeta, whatsappLink } from "@/lib/clinic-data";
import receptionPhoto from "@/assets/clinic-reception.png.asset.json";
import treatmentRoomPhoto from "@/assets/clinic-treatment-room.png.asset.json";
import consultationAreaPhoto from "@/assets/clinic-consultation-area.png.asset.json";
import entrancePhoto from "@/assets/clinic-entrance.png.asset.json";

export const Route = createFileRoute("/")({
  component: HomePage,
  head: () => clinicPageMeta(
    "British Dental Clinic | Abu Dhabi dentists since the 1970s",
    "Independent dental care in Khalidiya, Abu Dhabi. British Dental Clinic has cared for local families since the late 1970s.",
    "/",
  ),
});

const treatments = [
  ["01", "Cosmetic dentistry", "Veneers, whitening and smile makeovers, discussed around your needs."],
  ["02", "General dentistry", "Everyday dental care, including fillings, crowns and root canal treatment."],
  ["03", "Children’s dentistry", "A welcoming introduction to dental visits for younger patients."],
  ["04", "Braces & implants", "Orthodontic and restorative options, explained one step at a time."],
];

function HomePage() {
  return <>
    <section className="home-hero">
      <div className="hero-copy">
        <SectionEyebrow>Khalidiya · Abu Dhabi</SectionEyebrow>
        <h1>Abu Dhabi’s dentists <em>since the 1970s.</em></h1>
        <p>Thoughtful dental care for generations of local families, in the heart of Khalidiya.</p>
        <div className="hero-actions">
          <a className="button-primary" href={whatsappLink("Hello British Dental Clinic, I’d like to book an appointment.")} target="_blank" rel="noreferrer">Book on WhatsApp <ArrowUpRight /></a>
          <Link className="button-secondary" to="/treatments">View treatments <ArrowRight /></Link>
        </div>
      </div>
      <img src={entrancePhoto.url} alt="The British Dental Clinic entrance in Abu Dhabi" className="clinic-photo hero-photo" fetchPriority="high" />
      <span className="hero-index">KHALIDIYA PARK TOWER · ABU DHABI</span>
    </section>

    <section className="heritage-band">
      <div className="heritage-inner">
        <div className="heritage-number">40+<small>years in Abu Dhabi</small></div>
        <div className="heritage-copy"><SectionEyebrow>Our heritage</SectionEyebrow><h2>Care shaped by <em>time.</em></h2><p>Since the late 1970s, British Dental Clinic has been part of the Khalidiya community. Today, we continue that history with a considered approach to dental care.</p></div>
      </div>
    </section>

    <section className="section-wrap treatment-overview">
      <div className="overview-heading"><div><SectionEyebrow>Care at the clinic</SectionEyebrow><h2 className="section-title">A considered approach to every <em>visit.</em></h2></div><Link to="/treatments" className="text-link">Explore all treatments <ArrowRight /></Link></div>
      <div className="treatment-list">{treatments.map(([number, title, copy]) => <Link to="/treatments" key={number} className="treatment-row"><span>{number}</span><h3>{title}</h3><p>{copy}</p><ArrowRight aria-hidden="true" /></Link>)}</div>
    </section>

    <section className="section-wrap">
      <div className="editorial-split">
        <img src={receptionPhoto.url} alt="Reception and waiting area at British Dental Clinic" className="clinic-photo split-image" loading="lazy" />
        <div className="split-copy"><SectionEyebrow>Our clinic</SectionEyebrow><h2 className="section-title">A welcoming place to <em>visit.</em></h2><p>See the reception and waiting area at British Dental Clinic, in the heart of Khalidiya.</p><Link to="/patient-info" className="text-link split-link">Plan your visit <ArrowRight /></Link></div>
      </div>
    </section>

    <section className="home-gallery"><div className="section-wrap gallery-teaser"><div className="split-copy"><SectionEyebrow>Inside the clinic</SectionEyebrow><h2 className="section-title">A closer look at <em>our spaces.</em></h2><p>Explore the treatment room and consultation area at British Dental Clinic.</p><Link to="/smile-gallery" className="text-link split-link">See clinic photos <ArrowRight /></Link></div><img src={consultationAreaPhoto.url} alt="Consultation and waiting area at British Dental Clinic" className="clinic-photo gallery-teaser-photo" loading="lazy" /></div></section>

    <section className="section-wrap review-strip">
      <div><SectionEyebrow>Patient voices</SectionEyebrow><h2 className="section-title">Words from our <em>community.</em></h2></div>
      <div className="review-quote"><blockquote>“A place for the stories and words shared by our patients.”</blockquote><p className="quote-placeholder">Patient review placeholder — to be replaced with an approved, attributed review.</p></div>
    </section>

    <section className="visit-band"><div className="section-wrap visit-grid"><div className="visit-details"><SectionEyebrow>Visit the clinic</SectionEyebrow><h2>In the heart of <em>Khalidiya.</em></h2><address>{clinic.address}</address><a href="tel:+97126773308">{clinic.phone}</a><Link to="/patient-info" className="text-link">Plan your visit <ArrowRight /></Link></div><iframe className="visit-map" title="Map showing British Dental Clinic in Khalidiya, Abu Dhabi" loading="lazy" src="https://maps.google.com/maps?q=Khalidiya%20Park%20Tower%2C%20416%20Zayed%20The%20First%20St%2C%20Abu%20Dhabi&t=&z=15&ie=UTF8&iwloc=&output=embed" referrerPolicy="no-referrer-when-downgrade" /></div></section>
  </>;
}