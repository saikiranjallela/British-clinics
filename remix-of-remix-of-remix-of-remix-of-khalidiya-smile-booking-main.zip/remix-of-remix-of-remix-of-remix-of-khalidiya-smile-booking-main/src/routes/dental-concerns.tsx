import { createFileRoute } from "@tanstack/react-router";
import { PageIntro, SectionEyebrow } from "@/components/clinic-site";
import { clinicPageMeta } from "@/lib/clinic-data";

export const Route = createFileRoute("/dental-concerns")({
  component: DentalConcernsPage,
  head: () => clinicPageMeta("Dental Concerns | British Dental Clinic Abu Dhabi", "Answers to common dental questions about tooth pain, sensitivity, stained or missing teeth, and a child’s first dental visit.", "/dental-concerns"),
});

const concerns = [
  ["Tooth pain", "Tooth pain can have different causes. If you have ongoing or severe pain, contact the clinic to discuss an appointment. A dentist can assess the cause and explain options."],
  ["Tooth sensitivity", "Sensitivity may be related to several factors. Note what triggers it and arrange a dental assessment if it continues or worsens."],
  ["Stained teeth", "Tooth colour varies, and staining can have different causes. The clinic can discuss suitable options after understanding your dental health and goals."],
  ["Missing teeth", "There may be different ways to address a missing tooth. A dentist can discuss options such as an implant after an individual assessment."],
  ["A child’s first visit", "The team can explain what to expect and help plan an age-appropriate first visit. Contact the clinic if you have questions before booking."],
];

function DentalConcernsPage() {
  return <>
    <PageIntro eyebrow="Dental concerns" title={<>Questions, met with <em>care.</em></>} copy="Some common questions from patients and families. This information is general and is not a substitute for a dental assessment." />
    <section className="content-section"><div className="content-section-inner"><SectionEyebrow>Common questions</SectionEyebrow><div className="faq-list">{concerns.map(([question, answer]) => <details className="faq-item" key={question}><summary>{question}</summary><div className="faq-answer">{answer}</div></details>)}</div></div></section>
  </>;
}