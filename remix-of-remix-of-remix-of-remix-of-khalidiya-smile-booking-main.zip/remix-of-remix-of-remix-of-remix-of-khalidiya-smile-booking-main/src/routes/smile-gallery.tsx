import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { PageIntro, SectionEyebrow } from "@/components/clinic-site";
import { clinicPageMeta } from "@/lib/clinic-data";
import receptionPhoto from "@/assets/clinic-reception.png.asset.json";
import treatmentRoomPhoto from "@/assets/clinic-treatment-room.png.asset.json";
import consultationAreaPhoto from "@/assets/clinic-consultation-area.png.asset.json";
import entrancePhoto from "@/assets/clinic-entrance.png.asset.json";

export const Route = createFileRoute("/smile-gallery")({
  component: SmileGalleryPage,
  head: () => clinicPageMeta("Smile Gallery | British Dental Clinic Abu Dhabi", "A consent-led smile gallery from British Dental Clinic in Abu Dhabi. Patient photographs will be added only with permission.", "/smile-gallery"),
});

function CompareSlider({ number }: { number: string }) {
  const [split, setSplit] = useState(50);
  return <div className="slider-panel" style={{ "--split": `${split}%` } as React.CSSProperties}>
    <span className="slider-label before">Before</span><span className="slider-label after">After</span>
    <div className="slider-placeholder before">Patient image<br />placeholder</div><div className="slider-placeholder after">Patient image<br />placeholder</div>
    <input type="range" min="10" max="90" value={split} onChange={(event) => setSplit(Number(event.target.value))} aria-label={`Compare before and after placeholder ${number}`} />
  </div>;
}

function SmileGalleryPage() {
  return <>
    <PageIntro eyebrow="Clinic gallery" title={<>A closer look at the <em>practice.</em></>} copy="Explore the reception, consultation area, treatment room and entrance at British Dental Clinic." />
    <section className="content-section"><div className="content-section-inner"><SectionEyebrow>Inside the clinic</SectionEyebrow><div className="clinic-photo-grid">
      <figure><img src={receptionPhoto.url} alt="Reception and waiting area at British Dental Clinic" loading="lazy" /><figcaption>Reception</figcaption></figure>
      <figure><img src={treatmentRoomPhoto.url} alt="Dental treatment room at British Dental Clinic" loading="lazy" /><figcaption>Treatment room</figcaption></figure>
      <figure><img src={consultationAreaPhoto.url} alt="Consultation and waiting area at British Dental Clinic" loading="lazy" /><figcaption>Consultation area</figcaption></figure>
      <figure><img src={entrancePhoto.url} alt="The British Dental Clinic entrance in Abu Dhabi" loading="lazy" /><figcaption>Clinic entrance</figcaption></figure>
    </div></div></section>
  </>;
}