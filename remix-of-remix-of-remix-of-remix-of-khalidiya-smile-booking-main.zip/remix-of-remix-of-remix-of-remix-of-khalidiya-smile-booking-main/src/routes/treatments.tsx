import { createFileRoute } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { PageIntro, SectionEyebrow } from "@/components/clinic-site";
import { askAboutTreatment, clinicPageMeta } from "@/lib/clinic-data";

export const Route = createFileRoute("/treatments")({
  component: TreatmentsPage,
  head: () => clinicPageMeta("Dental Treatments | British Dental Clinic Abu Dhabi", "Explore cosmetic, general, children’s, orthodontic and implant dentistry at British Dental Clinic in Abu Dhabi.", "/treatments"),
});

const items = [
  ["01", "Cosmetic dentistry & smile makeovers", "A conversation about the changes you’re considering and the options that may be appropriate. Services include veneers, teeth whitening and gum contouring."],
  ["02", "General dentistry", "Care for common dental needs, including fillings, root canal treatment and crowns. The clinic can discuss what is suitable for your situation."],
  ["03", "Children’s dentistry", "Dental appointments for children, with time to talk through the visit and their individual needs."],
  ["04", "Adult braces & orthodontics", "Orthodontic options for adults, discussed with the clinician following an assessment."],
  ["05", "Dental implants", "Implant treatment enquiries can be discussed with the clinic team, including the assessment and next steps."],
] as const;
function TreatmentsPage() {
  return <>
    <PageIntro eyebrow="Treatments" title={<>Care, considered <em>individually.</em></>} copy="Explore the areas of dentistry available at British Dental Clinic. A clinician can discuss your needs and explain suitable options." />
    <section className="content-section"><div className="content-section-inner"><SectionEyebrow>Areas of care</SectionEyebrow>{items.map(([number, title, copy]) => <article className="treatment-detail" key={number}><span className="treatment-detail-number">{number}</span><h2>{title}</h2><p>{copy}</p><a className="text-link" href={askAboutTreatment(title)} target="_blank" rel="noreferrer">Ask about this on WhatsApp <ArrowUpRight /></a></article>)}</div></section>
  </>;
}