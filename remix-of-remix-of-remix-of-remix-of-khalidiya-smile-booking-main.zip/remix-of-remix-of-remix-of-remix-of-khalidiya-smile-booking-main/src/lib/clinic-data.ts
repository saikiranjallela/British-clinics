import { z } from "zod";

export const clinic = {
  name: "British Dental Clinic",
  legalName: "British Dental Medical Clinic LLC",
  phone: "+971 2 677 3308",
  whatsapp: "971503137733",
  address: "Khalidiya Park Tower, Mezzanine Floor, 416 Zayed The First St, Al Khalidiyah, Abu Dhabi, UAE",
  facebook: "https://www.facebook.com/britishdentalclinic",
  legal: "© 2026 British Dental Medical Clinic LLC, PO Box 4374, Abu Dhabi, UAE. MOH: MF193 / CN-1042961. MOHAP Advertisement License No: WI5O55HM-220226, valid until 18/02/2027.",
} as const;

export const treatmentOptions = [
  "Cosmetic dentistry & smile makeovers",
  "Veneers",
  "Teeth whitening",
  "Gum contouring",
  "General dentistry",
  "Fillings",
  "Root canal treatment",
  "Crowns",
  "Children’s dentistry",
  "Adult braces & orthodontics",
  "Dental implants",
  "Not sure yet",
] as const;

export const appointmentSchema = z.object({
  name: z.string().trim().min(2).max(100),
  phone: z.string().trim().min(7).max(20).regex(/^\+?[0-9][0-9\s()-]{6,19}$/),
  treatment: z.enum(treatmentOptions),
  day: z.string().trim().min(2).max(80),
  time: z.enum(["Morning", "Afternoon", "Evening", "Flexible"]),
  patient: z.enum(["New patient", "Existing patient"]),
});

export function whatsappLink(message?: string) {
  const base = `https://wa.me/${clinic.whatsapp}`;
  return message ? `${base}?text=${encodeURIComponent(message)}` : base;
}

export function askAboutTreatment(treatment: string) {
  return whatsappLink(`Hello British Dental Clinic, I’d like to ask about ${treatment}.`);
}

export function clinicPageMeta(title: string, description: string, path: string) {
  return {
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: path },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: title },
      { name: "twitter:description", content: description },
    ],
    scripts: [{
      type: "application/ld+json",
      children: JSON.stringify({
        "@context": "https://schema.org",
        "@type": "Dentist",
        name: clinic.name,
        telephone: clinic.phone,
        address: {
          "@type": "PostalAddress",
          streetAddress: "Khalidiya Park Tower, Mezzanine Floor, 416 Zayed The First St, Al Khalidiyah",
          addressLocality: "Abu Dhabi",
          addressCountry: "AE",
        },
      }),
    }],
  };
}