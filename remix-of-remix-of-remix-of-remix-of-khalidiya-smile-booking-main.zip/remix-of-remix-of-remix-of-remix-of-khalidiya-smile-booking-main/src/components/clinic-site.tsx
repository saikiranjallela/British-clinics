import { useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { ArrowDown, ArrowRight, ArrowUpRight, Menu, MessageCircle, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { appointmentSchema, clinic, treatmentOptions, whatsappLink } from "@/lib/clinic-data";
import clinicLogo from "@/assets/british-dental-clinic-logo-transparent.png.asset.json";

const navLinks = [
  { to: "/dentists", label: "Our Dentists" },
  { to: "/treatments", label: "Treatments" },
  { to: "/smile-gallery", label: "Smile Gallery" },
  { to: "/dental-concerns", label: "Dental Concerns" },
  { to: "/patient-info", label: "Patient Info" },
] as const;

export function SiteHeader() {
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const [open, setOpen] = useState(false);
  return (
    <header className="site-header">
      <div className="header-inner">
        <Link to="/" className="brand-mark" aria-label="British Dental Clinic home" onClick={() => setOpen(false)}>
          <img className="brand-logo" src={clinicLogo.url} alt="" />
          <span className="brand-name">BRITISH DENTAL CLINIC<small>ABU DHABI · EST. 1978</small></span>
        </Link>
        <nav className="desktop-nav" aria-label="Main navigation">
          {navLinks.map((link) => <Link key={link.to} to={link.to} className={`nav-link${pathname === link.to ? " active" : ""}`}>{link.label}</Link>)}
        </nav>
        <a className="header-cta" href={whatsappLink("Hello British Dental Clinic, I’d like to book an appointment.")} target="_blank" rel="noreferrer">Book on WhatsApp <ArrowUpRight aria-hidden="true" /></a>
        <Button variant="ghost" size="icon" aria-label={open ? "Close navigation menu" : "Open navigation menu"} aria-expanded={open} className="menu-toggle" onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</Button>
      </div>
      {open && <nav className="mobile-nav" aria-label="Mobile navigation">
        <p className="eyebrow">Explore the clinic</p>
        {navLinks.map((link, index) => <Link key={link.to} to={link.to} onClick={() => setOpen(false)}><span className="mobile-nav-number">0{index + 1}</span>{link.label}<ArrowRight aria-hidden="true" /></Link>)}
        <a className="mobile-book" href={whatsappLink("Hello British Dental Clinic, I’d like to book an appointment.")} target="_blank" rel="noreferrer">Book on WhatsApp <ArrowUpRight /></a>
      </nav>}
    </header>
  );
}

export function SiteFooter() {
  return <footer className="site-footer">
    <div className="footer-main">
      <div className="footer-intro"><img className="footer-logo" src={clinicLogo.url} alt="British Dental Clinic" /><p>Considered dental care,<br />rooted in Abu Dhabi.</p></div>
      <div className="footer-column"><p className="eyebrow">Find us</p><p>{clinic.address}</p><a href="https://maps.google.com/?q=Khalidiya+Park+Tower,+416+Zayed+The+First+St,+Abu+Dhabi" target="_blank" rel="noreferrer">Get directions <ArrowUpRight /></a></div>
      <div className="footer-column"><p className="eyebrow">Speak with us</p><a href="tel:+97126773308">{clinic.phone}</a><a href={whatsappLink()} target="_blank" rel="noreferrer">WhatsApp <ArrowUpRight /></a><a href={clinic.facebook} target="_blank" rel="noreferrer">Facebook <ArrowUpRight /></a></div>
      <div className="footer-column"><p className="eyebrow">Clinic hours</p><p>Hours to be confirmed</p><Link to="/patient-info">Plan your visit <ArrowRight /></Link></div>
    </div>
    <div className="footer-bottom"><p>{clinic.legal}</p><Link to="/contact">Contact the clinic <ArrowRight /></Link></div>
  </footer>;
}

export function FloatingWhatsApp() {
  return <a className="floating-whatsapp" href={whatsappLink("Hello British Dental Clinic, I’d like to book an appointment.")} target="_blank" rel="noreferrer" aria-label="Book an appointment on WhatsApp"><MessageCircle aria-hidden="true" /><span>WhatsApp</span></a>;
}

export function SectionEyebrow({ children }: { children: React.ReactNode }) {
  return <p className="eyebrow"><span className="eyebrow-rule" />{children}</p>;
}

export function AppointmentForm() {
  const [confirmation, setConfirmation] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    const parsed = appointmentSchema.safeParse({
      name: String(data.get("name") ?? ""), phone: String(data.get("phone") ?? ""), treatment: String(data.get("treatment") ?? ""),
      day: String(data.get("day") ?? ""), time: String(data.get("time") ?? ""), patient: String(data.get("patient") ?? ""),
    });
    const next: Record<string, string> = {};
    if (!parsed.success) for (const issue of parsed.error.issues) {
      const field = String(issue.path[0] ?? "");
      if (field) next[field] = field === "phone" ? "Enter a valid phone number." : `Please check this ${field} field.`;
    }
    setErrors(next);
    setConfirmation("");
    if (Object.keys(next).length) return;
    if (!parsed.success) return;
    const { name, phone, treatment, day, time, patient } = parsed.data;
    const message = `Hello British Dental Clinic, I'd like to book an appointment. Name: ${name}, Phone: ${phone}, Treatment: ${treatment}, Preferred day/time: ${day} / ${time}, Patient: ${patient}.`;
    window.open(whatsappLink(message), "_blank", "noopener,noreferrer");
    setConfirmation("Your appointment request is ready in WhatsApp. Please send the message to complete your enquiry.");
    form.reset();
  }
  return <form className="appointment-form" onSubmit={submit} noValidate>
    <div className="form-grid">
      <label>Name<input name="name" autoComplete="name" required maxLength={100} aria-invalid={Boolean(errors["name"])} placeholder="Your full name" />{errors["name"] && <small className="field-error">{errors["name"]}</small>}</label>
      <label>Phone<input name="phone" autoComplete="tel" required maxLength={20} aria-invalid={Boolean(errors["phone"])} placeholder="+971 5X XXX XXXX" />{errors["phone"] && <small className="field-error">{errors["phone"]}</small>}</label>
      <label>Treatment<select name="treatment" required defaultValue="" aria-invalid={Boolean(errors["treatment"])}><option value="" disabled>Select a treatment</option>{treatmentOptions.map((item) => <option key={item}>{item}</option>)}</select>{errors["treatment"] && <small className="field-error">{errors["treatment"]}</small>}</label>
      <label>Preferred day<input name="day" required maxLength={80} aria-invalid={Boolean(errors["day"])} placeholder="For example, Tuesday" />{errors["day"] && <small className="field-error">{errors["day"]}</small>}</label>
      <label>Preferred time<select name="time" required defaultValue="" aria-invalid={Boolean(errors["time"])}><option value="" disabled>Select a time slot</option><option>Morning</option><option>Afternoon</option><option>Evening</option><option>Flexible</option></select>{errors["time"] && <small className="field-error">{errors["time"]}</small>}</label>
      <label>Patient type<select name="patient" required defaultValue="" aria-invalid={Boolean(errors["patient"])}><option value="" disabled>Select one</option><option>New patient</option><option>Existing patient</option></select>{errors["patient"] && <small className="field-error">{errors["patient"]}</small>}</label>
    </div>
    <div className="form-submit"><Button type="submit" className="button-primary">Continue to WhatsApp <ArrowUpRight /></Button><p>We’ll open a message for you to review and send.</p></div>
    {confirmation && <p className="form-confirmation" role="status">{confirmation}</p>}
  </form>;
}

export function PageIntro({ eyebrow, title, copy }: { eyebrow: string; title: React.ReactNode; copy: string }) {
  return <section className="page-intro"><SectionEyebrow>{eyebrow}</SectionEyebrow><h1>{title}</h1><p>{copy}</p><ArrowDown className="intro-arrow" aria-hidden="true" /></section>;
}